# Agentic Orchestration Control

<p align="center">
  <img src="workflow-diagram.png" alt="Agentic Orchestration Control workflow" width="100%" />
</p>

<p align="center">
  <em>Explicit-only, token-aware orchestration control room for Codex subagents.</em>
</p>

<p align="center">
  <a href="https://github.com/ZypherHQ/agent-orchestration-skill">
    <img src="https://img.shields.io/badge/GitHub-ZypherHQ%2Fagent--orchestration--skill-111827?style=for-the-badge&labelColor=0f172a" alt="GitHub repository" />
  </a>
  <a href="LICENSE">
    <img src="https://img.shields.io/badge/License-MIT-22c55e?style=for-the-badge&labelColor=0f172a" alt="MIT License" />
  </a>
  <img src="https://img.shields.io/badge/Layout-skills%2F%20%2B%20subagents%2F-2563eb?style=for-the-badge&labelColor=0f172a" alt="skills and subagents layout" />
</p>

Agentic Orchestration Control is a production-focused package for disciplined Codex orchestration. It installs a single explicit-only skill, subagent profiles, deterministic validation utilities, a filesystem-first control room, and short npm/npx commands for TUI, GUI, usage, budget, gates, events, memory, and optional Codex app-server visibility.

The design goal is simple:

```text
root session stays in control
workers stay leaf-only
context is preserved without prompt bloat
subagents are spawned only when useful
test/evidence/usage are visible per orchestrator session
```

## Install

From npm after publication:

```bash
npx agentic-orchestration-control install .
```

From a local tarball:

```bash
npx --yes --package ./dist/agentic-orchestration-control-0.1.0.tgz \
  agentic-orchestration-control install .
```

Local package development:

```bash
npm install
npm test
npm run publish:check
```

The production layout is intentionally:

```text
skills/agent-orchestration-skill/   # skill payload
subagents/                          # custom worker configs
.orchestration/                     # runtime state, events, control-room data
```

Hidden `.skills/`, `.agents/`, and `.codex/agents` layouts are treated as legacy and are backed up during install to avoid duplicate discovery and path confusion.

## Use the skill

The skill is explicit-only. It should run only when the prompt contains the exact literal:

```text
$agent-orchestration-skill
```

Recommended Codex prompt:

```text
Use $agent-orchestration-skill for this task.

Run in token-efficient control-plane mode.
Preserve context with a scoped Context Capsule.
Spawn only useful leaf workers.
Do not spawn one agent per file.
Use low for scouting, medium for normal coding/testing, high for complex implementation, and xhigh only for rare architecture/planning.
```

Prompts without `$agent-orchestration-skill` should not create orchestration artifacts or run the control-plane workflow.

## Short commands

After local or global installation:

```bash
aoc                    # terminal control room
aoc gui                # local web GUI
aoc usage              # usage report
aoc budget 12000       # usage/budget check
aoc stats              # orchestration statistics
aoc events             # event stream
aoc gates              # STOP gate status
aoc memory build       # build inspectable memory index
aoc codex doctor       # optional Codex app-server/codexui readiness check
```

Via npx:

```bash
npx agentic-orchestration-control
npx agentic-orchestration-control gui
npx agentic-orchestration-control usage
npx agentic-orchestration-control budget 12000
npx agentic-orchestration-control codex doctor
```

## Initialize an observable run

For production runs, initialize a real run ledger instead of generating artificial demo data:

```bash
aoc init --run-id latest --task "verify backend doctor rules"
```

Then the skill/runtime can append events, dispatches, handoffs, evidence, memory, and usage under:

```text
.orchestration/runs/<run_id>/
.orchestration/events.jsonl
.orchestration/usage/
.orchestration/memory/
```

## TUI and GUI

Terminal control room:

```bash
aoc
```

Non-interactive snapshot:

```bash
aoc snapshot --run-id latest
```

Local GUI:

```bash
aoc gui --run-id latest
```

HTML snapshot:

```bash
aoc gui --run-id latest --once > /tmp/aoc.html
```

The GUI is local-only by default. Remote/mobile access requires explicit opt-in and an auth token:

```bash
AOC_GUI_TOKEN="change-me" \
  aoc gui --host 0.0.0.0 --allow-remote --auth-token "$AOC_GUI_TOKEN"
```

## Optional Codex app-server / codexui bridge

The control room can show optional runtime hints for Codex app-server/codexui:

```bash
aoc codex doctor
aoc codex status
aoc gui --with-codex --codex-url http://127.0.0.1:<port>
```

This bridge is not the source of truth for orchestration. The source of truth remains `.orchestration/`. Codex app-server/codexui visibility is an optional live-runtime layer.

## What the package enforces

- **Explicit-only activation:** the skill runs only with `$agent-orchestration-skill`.
- **Root-only orchestration:** subagents receive scoped dispatches, not skill names.
- **Leaf-worker boundaries:** workers must not spawn child agents or invoke skills.
- **Context Capsule:** important context is saved to disk instead of relying on chat memory.
- **Scoped Dispatch Packets:** workers receive only the context slice they need.
- **Context Coverage Gate:** workers must read required context before editing.
- **Token budget discipline:** dispatches, fan-out, reasoning, handoffs, and usage are capped/visible.
- **Batching over fan-out:** one worker can inspect, patch, and validate related files.
- **STOP gates:** plan, budget, xhigh, browser QA, retry, and risky commands can be gated.
- **Run Ledger:** phases, events, dispatches, handoffs, evidence, failures, and state are recorded.
- **Failure recovery:** failures are classified before retry, replan, or escalation.
- **Usage control:** real/imported usage and estimated orchestration pressure are kept separate.
- **TUI/GUI:** sessions, worker lanes, events, memory, gates, usage, and stats are visible.

## Reasoning policy

```text
low    -> scouts, file discovery, docs/source checks, exact commands
medium -> normal fixes, batch implementation, browser QA, verification
high   -> complex logic, security-sensitive work, data/concurrency paths
xhigh  -> rare architecture/planning only; preferably read-only
```

`xhigh` is not a default update mode.

## Publish to npm

Before publishing:

```bash
npm install
npm run validate:production
```

Publish unscoped:

```bash
npm publish
```

Publish scoped:

```bash
npm pkg set name="@zypherhq/agentic-orchestration-control"
npm publish --access public
```

Post-publish smoke test:

```bash
mkdir -p /tmp/aoc-npx-test
cd /tmp/aoc-npx-test
git init -q
npx agentic-orchestration-control install .
npx agentic-orchestration-control init --run-id smoke --task "smoke"
npx agentic-orchestration-control snapshot --run-id smoke
npx agentic-orchestration-control gui --run-id smoke --once > /tmp/aoc-smoke.html
```

## Repository layout

| Path | Purpose |
| --- | --- |
| `skills/agent-orchestration-skill/SKILL.md` | Explicit-only root orchestration skill. |
| `skills/agent-orchestration-skill/scripts/` | Deterministic planning, state, validation, usage, TUI, and GUI utilities. |
| `skills/agent-orchestration-skill/references/` | Focused orchestration policies. |
| `skills/agent-orchestration-skill/bin/` | Local skill-level command wrappers. |
| `subagents/` | Worker configs with reasoning and leaf-worker boundaries. |
| `bin/aoc.mjs` | npm/npx CLI router. |
| `tools/fix-permissions.mjs` | Normalizes executable bits before tests/publish. |
| `tests/` | Production validation tests. |
| `.orchestration/` | Runtime state created after install/run. |

## License

MIT License. See [LICENSE](LICENSE).
